package com.example.student.myapplication;

/**
 * Created by student on 4.06.2018.
 */


import android.content.Context;
import android.os.AsyncTask;
import android.support.v7.widget.RecyclerView;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;



public class FetchData extends AsyncTask<String,Void,String> {
    private ArrayList<data> lbooks;
    private RecyclerView aRecyclerView;
    private RecyclerView.Adapter aAdapter;
    Context c;


    public FetchData(ArrayList<data> listofbooks) {
        lbooks=listofbooks;
    }

    public FetchData(Adaptor mAdapter, RecyclerView mRecyclerView,Context con) {
        aAdapter=mAdapter;
        aRecyclerView=mRecyclerView;
        c=con;
    }

    @Override
    protected String doInBackground(String... strings) {
        return NetworkUtils.getBookInfo(strings[0]);

    }

    @Override
    protected void onPostExecute(String s) {
        lbooks=new ArrayList<data>();
        super.onPostExecute(s);
//        Log.d("ne",s);
        try {
            JSONObject jsonObject = new JSONObject(s);
            Log.e("Json",jsonObject.optString("countryName"));
            //JSONArray itemsArray = jsonObject.getJSONArray("");
            // Log.d("num2", String.valueOf(itemsArray.length()));
            String  countryCode=null;
            String  countryName=null;
            try {

                try {
                    countryName=jsonObject.getString("countryName");
                    if (countryName==""||countryName==null){
                        countryName="unknown";
                    }
                }catch (Exception e){
                    countryName="unknown";
                }
                try {
                    countryCode=jsonObject.getString("countryCode");
                    if (countryCode==""||countryCode==null){
                        countryCode="unknown";
                    }
                }catch (Exception e){
                    countryName="unknown";
                }

                data dummy=new data(countryCode,countryName);
                lbooks.add(dummy);
                Log.d("neoluyo",lbooks.get(0).getCountryName());
            }catch (Exception e){
                e.getStackTrace();
            }




            aAdapter=new Adaptor(c,lbooks);
            aRecyclerView.setAdapter(aAdapter);


        } catch (Exception e){

            e.printStackTrace();
        }


    }
}
