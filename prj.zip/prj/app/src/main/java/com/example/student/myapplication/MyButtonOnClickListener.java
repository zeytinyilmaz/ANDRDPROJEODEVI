package com.example.student.myapplication;

import android.view.View;

/**
 * Created by student on 28.05.2018.
 */

class MyButtonOnClickListener implements View.OnClickListener {
    data dat;

    public MyButtonOnClickListener(data d) {
        dat = d;
    }

    public void onClick(View v) {
        // Implemented in WordListAdapter

    }

    public data getDat() {
        return dat;
    }
}
