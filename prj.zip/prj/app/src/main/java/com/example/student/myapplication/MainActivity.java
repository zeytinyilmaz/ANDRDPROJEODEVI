package com.example.student.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private RecyclerView mRecyclerView;
    private Adaptor mAdapter;
    ArrayList<data> listofbooks;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



    }

    public void searchbooks(View view) {

            listofbooks = new ArrayList<data>();
            EditText e = findViewById(R.id.plain_text_input);
            String search = e.getText().toString();
            if (search.equals("") || search.equals(null)) {
                Toast.makeText(this, "Lütfen boş bırakmayınız", Toast.LENGTH_SHORT).show();
            } else {
                mRecyclerView = (RecyclerView) findViewById(R.id.recyclerview);

                mRecyclerView.setLayoutManager(new LinearLayoutManager(this));

                // new FetchBook(listofbooks).execute(search);
                new FetchData(mAdapter, mRecyclerView, this).execute(search);
                Log.d("neoluyo", listofbooks.size() + "");
            }




    }
}
