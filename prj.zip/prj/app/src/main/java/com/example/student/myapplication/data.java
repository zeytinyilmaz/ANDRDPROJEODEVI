package com.example.student.myapplication;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by student on 28.05.2018.
 */

public class data implements Parcelable {
    String  countryCode;
    String  countryName;
    String ip;

    public data(String countryCode, String countryName, String ip) {
        this.countryCode = countryCode;
        this.countryName = countryName;
        this.ip = ip;
    }

    public data(String countryCode, String countryName) {
        this.countryCode = countryCode;
        this.countryName = countryName;
    }

    protected data(Parcel in) {
        countryCode = in.readString();
        countryName = in.readString();
    }

    public String getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    public String getCountryName() {
        return countryName;
    }

    public void setCountryName(String countryName) {
        this.countryName = countryName;
    }

    public static Creator<data> getCREATOR() {
        return CREATOR;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(countryCode);
        dest.writeString(countryName);
    }

    @SuppressWarnings("unused")
    public static final Parcelable.Creator<data> CREATOR = new Parcelable.Creator<data>() {
        @Override
        public data createFromParcel(Parcel in) {
            return new data(in);
        }

        @Override
        public data[] newArray(int size) {
            return new data[size];
        }
    };
}
