package com.example.student.myapplication;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

/**
 * Created by student on 4.06.2018.
 */

public class Adaptor extends RecyclerView.Adapter<Adaptor.WordViewHolder> {



    class WordViewHolder extends RecyclerView.ViewHolder {
        TextView wordItemView;
        Button search_button;
        Button edit_button;


        public WordViewHolder(View itemView) {
            super(itemView);
            wordItemView = (TextView) itemView.findViewById(R.id.word);
            search_button = (Button)itemView.findViewById(R.id.search_button);

        }
    }//viewholder

    private final LayoutInflater mInflater;
    Context mContext;
    ArrayList<data> lbooks;
    public Adaptor(Context context, ArrayList<data> listofbooks) {
        lbooks=listofbooks;
        mInflater = LayoutInflater.from(context);
        mContext = context;

    }


    @Override
    public WordViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = mInflater.inflate(R.layout.items, parent, false);
        return new Adaptor.WordViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(final WordViewHolder holder, int position) {

        data d=lbooks.get(position);
        final Adaptor.WordViewHolder h = holder;
        holder.wordItemView.setText(d.getCountryName());
        holder.search_button.setOnClickListener(
                new MyButtonOnClickListener(d)  {

                    @Override
                    public void onClick(View v ) {


                        try{

                            Intent intent = new Intent(mContext, EditData.class);
                            //start intent
                            intent.putExtra("datasent", getDat());
                            intent.putExtra("ip", holder.wordItemView.getText().toString());
                            mContext.startActivity(intent);
                        }
                        catch (Exception ex){
                            Toast.makeText(mContext, "Bir hata oluştu", Toast.LENGTH_SHORT).show();
                        }



                    }
                });


    }

    @Override
    public int getItemCount() {
        return (int) lbooks.size();
    }
}
